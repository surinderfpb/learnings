./sbin/mr-jobhistory-daemon.sh stop historyserver
./sbin/yarn-daemons.sh stop nodemanager
./sbin/yarn-daemon.sh stop resourcemanager
./sbin/hadoop-daemons.sh stop datanode
./sbin/hadoop-daemon.sh stop namenode
