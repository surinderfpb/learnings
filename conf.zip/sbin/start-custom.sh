./sbin/hadoop-daemon.sh start namenode
./sbin/hadoop-daemons.sh start datanode
./sbin/yarn-daemon.sh start resourcemanager
./sbin/yarn-daemons.sh start nodemanager
./sbin/mr-jobhistory-daemon.sh start historyserver
